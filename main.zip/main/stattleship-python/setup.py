from distutils.core import setup


setup(
    name='stattlepy',
    version='0.0.1',
    author = ['Adam Jenkins', 'Stattleship'],
    packages=['stattlepy'],
    license='MIT',
    long_description=open('README.md').read(),
)
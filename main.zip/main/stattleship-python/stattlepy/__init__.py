### Import Statteleship class upon initiation of the program
from .Stattleship_API import Stattleship

from pkg_resources import get_distribution

__version__ = get_distribution('stattlepy').version